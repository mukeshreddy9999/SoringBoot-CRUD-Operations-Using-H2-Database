package com.EmployeeDemo.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.EmployeeDemo.Employee.*;
public interface EmpRepository extends JpaRepository<Employee, Integer>{

}
