package com.EmployeeDemo.Service;
import com.EmployeeDemo.Employee.*;
import com.EmployeeDemo.Repository.*;

public interface EmpService {

	public Employee getEmployeeById(int id);
	Employee updateEmployee(Employee employee);
}
