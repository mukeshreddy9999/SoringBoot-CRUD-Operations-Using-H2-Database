package com.EmployeeDemo.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.EmployeeDemo.Employee.Employee;
import com.EmployeeDemo.Repository.EmpRepository;
import com.EmployeeDemo.Service.EmpService;

@Service
public class EmpServiceImpl implements EmpService {
	private final EmpRepository EmpRepository;
	
	@Autowired
	public EmpServiceImpl(EmpRepository EmpRepository) {
		this.EmpRepository= EmpRepository;
	}

	@Override
	public Employee getEmployeeById(int id) {
		return EmpRepository.findById(id).orElse(null);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
     Employee existingemployee=EmpRepository.findById(employee.getId()).orElse(null);
     existingemployee.setName(employee.getName());
     existingemployee.setCompany(employee.getCompany());
     existingemployee.setSalary(employee.getSalary());
     EmpRepository.save(employee);
     return existingemployee;
     
	}

	
}
