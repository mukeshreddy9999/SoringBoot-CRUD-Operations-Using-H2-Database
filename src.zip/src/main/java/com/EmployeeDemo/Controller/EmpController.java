package com.EmployeeDemo.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.EmployeeDemo.Service.*;

import com.EmployeeDemo.Employee.*;
import com.EmployeeDemo.Service.*;

@RestController
public class EmpController {
	
	private final EmpService empService;
	@Autowired
	public EmpController(EmpService empService) {
		this.empService=empService;
	}
	
	@GetMapping("/getEmployeeById/{id}")
	public Employee getEmployeeById(@PathVariable int id) {
		return empService.getEmployeeById(id);
	}
	@PutMapping("/updateEmployee")
	public Employee updateEmployee(@RequestBody Employee employee) {
	return empService.updateEmployee(employee);
}
}
